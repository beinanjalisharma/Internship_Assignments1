var Roles;
(function (Roles) {
    Roles["Manager"] = "Manager";
    Roles["Developer"] = "Developer";
    Roles["Intern"] = "Intern";
})(Roles || (Roles = {}));
var Status;
(function (Status) {
    Status["Active"] = "Active";
    Status["Inactive"] = "Inactive";
})(Status || (Status = {}));
var employees = [];
// function to get an employee by ID
function getEmployeeById(id) {
    return employees.find(function (emp) { return emp.id === id; });
}
// Add a new employee to the list
function addEmployee(employee) {
    employees.push(employee);
}
// Update the status of an employee
function updateEmployee(id, updates) {
    var employee = getEmployeeById(id);
    if (employee) {
        Object.assign(employee, updates);
    }
}
// Generate summaries of all employees
function generateEmployeeSummaries() {
    return employees.map(function (e) { return ({ name: e.name, role: e.role, status: e.status }); });
}
// Group employees by their role
function groupEmployeesByRole() {
    var _a;
    var employeeGroups = (_a = {},
        _a[Roles.Manager] = [],
        _a[Roles.Developer] = [],
        _a[Roles.Intern] = [],
        _a);
    employees.forEach(function (employee) {
        employeeGroups[employee.role].push(employee);
    });
    return employeeGroups;
}
// Adding employees
addEmployee({ id: 1, name: "Sandhya", role: Roles.Manager, status: Status.Active });
addEmployee({ id: 2, name: "Rutuja", role: Roles.Developer, status: Status.Active });
addEmployee({ id: 3, name: "Neha", role: Roles.Intern, status: Status.Inactive });
// Updating an employee's status
updateEmployee(3, { status: Status.Active });
// Generating and displaying employee summaries
var summaries = generateEmployeeSummaries();
console.log("Employee Summaries:", summaries);
// Grouping employees by role 
var groupedEmployees = groupEmployeesByRole();
console.log("Grouped Employees by Role:", groupedEmployees);
