"use strict";
//Role Based Access Control System.
var Role;
(function (Role) {
    Role["Admin"] = "Admin";
    Role["Editor"] = "Editor";
    Role["Viewer"] = "Viewer";
})(Role || (Role = {}));
function checkPermission(user, requiredPermission) {
    return user.permissions[requiredPermission];
}
// Sample users
const adminUser = {
    id: 1,
    name: "Admin User",
    role: Role.Admin,
    permissions: {
        canEdit: true,
        canView: true,
        canDelete: true
    }
};
const editorUser = {
    id: 2,
    name: "Editor User",
    role: Role.Editor,
    permissions: {
        canEdit: true,
        canView: true,
        canDelete: false
    }
};
const viewerUser = {
    id: 3,
    name: "Viewer User",
    role: Role.Viewer,
    permissions: {
        canEdit: false,
        canView: true,
        canDelete: false
    }
};
// Test the permission logic
console.log(checkPermission(adminUser, 'canEdit')); // Output: true
console.log(checkPermission(editorUser, 'canDelete')); // Output: false
console.log(checkPermission(viewerUser, 'canView')); // Output: true
