// enum for User Roles//enum
enum UserRole {
    Admin = "admin",
    Manager = "manager",
    Employee = "employee"
}

// Interface - User having properties id,name,email,role,phone number
interface User {
    id: number;
    name: string;
    email: string;
    role: UserRole | string;  
    phoneNumber?: string;  
}

const newUSer: User={
    id: 101, 
    name: "Sandhya",
    email: "sandhya@gmail.com",
    role: UserRole.Admin,
    phoneNumber: "9876543210"
}

const newUSer1: User={
    id: 102, 
    name: "Rutuja",
    email: "rutuja@gmail.com",
    role: UserRole.Manager,
    phoneNumber: "1023456789"
}

const newUSer2: User={
    id: 103, 
    name: "Neha",
    email: "neha@gmail.com",
    role: UserRole.Employee,
}

// Function to create a User object
function createUser(user: User): User { 
    return user;
}

// Function to filter users based on roles
function getUsersByRoles(users: User[], roles: (UserRole | string)[]): User[] {
    return users.filter(user => roles.includes(user.role));
}

// List of users
const users: User[] = [newUSer, newUSer1, newUSer2];

// Filter users based on Admin and Manager roles
let AdminsManagers = getUsersByRoles(users, [UserRole.Admin, UserRole.Manager]);
console.log(AdminsManagers);
